/* eslint-disable  func-names */
/* eslint quote-props: ["error", "consistent"]*/
/**
 * This sample demonstrates a simple skill built with the Amazon Alexa Skills
 * nodejs skill development kit.
 * This sample supports multiple lauguages. (en-US, en-GB, de-DE).
 * The Intent Schema, Custom Slots and Sample Utterances for this skill, as well
 * as testing instructions are located at https://github.com/alexa/skill-sample-nodejs-fact
 **/

'use strict';
const Alexa = require('alexa-sdk');

//=========================================================================================================================================
//TODO: The items below this comment need your attention.
//=========================================================================================================================================

//Replace with your app ID (OPTIONAL).  You can find this value at the top of your skill's page on http://developer.amazon.com.
//Make sure to enclose your value in quotes, like this: const APP_ID = 'amzn1.ask.skill.bb4045e6-b3e8-4133-b650-72923c5980f1';
const APP_ID = 'amzn1.ask.skill.0b1efe40-2f34-4e9c-98fd-0aa9dc2284c1';

const SKILL_NAME = 'BMRCalculator';
const GET_BMR_MESSAGE = "Your daily recommended intake is: ";
const HELP_MESSAGE = 'You can say tell me my recommended daily intake, or, you can say exit... What can I help you with?';
const HELP_REPROMPT = 'What can I help you with?';
const STOP_MESSAGE = 'Goodbye!';

const handlers = {
    'LaunchRequest': function () {
        this.emit(':ask','Welcome. Can you please provide your age, gender, weight in kilos and height in centimetre?');
    },
    'bmrCalculatorIntent': function () {
        const age    = this.event.request.intent.slots.age.value;
        const weight = this.event.request.intent.slots.weight.value;
        const height = this.event.request.intent.slots.height.value;
        let gender   = this.event.request.intent.slots.gender.value;
        var bmr;
        var calc = (10 * weight) + (6.25 * height) - (5 * age);
        
        if(gender == "male")
	    {
		    bmr = calc + 5;
	    }
	    else if(gender == "female")
	    {
		    bmr = calc - 161;
	    }
   
        const speechOutput = GET_BMR_MESSAGE + bmr + ' kilocalories'; 
        this.response.cardRenderer(SKILL_NAME, bmr);
        this.response.speak(speechOutput);
        this.emit(':responseReady');
    },
    'AMAZON.HelpIntent': function () {
        const speechOutput = HELP_MESSAGE;
        const reprompt = HELP_REPROMPT;

        this.response.speak(speechOutput).listen(reprompt);
        this.emit(':responseReady');
    },
    'AMAZON.CancelIntent': function () {
        this.response.speak(STOP_MESSAGE);
        this.emit(':responseReady');
    },
    'AMAZON.StopIntent': function () {
        this.response.speak(STOP_MESSAGE);
        this.emit(':responseReady');
    },
};

exports.handler = function (event, context, callback) {
    const alexa = Alexa.handler(event, context, callback);
    alexa.APP_ID = APP_ID;
    alexa.registerHandlers(handlers);
    alexa.execute();
};
