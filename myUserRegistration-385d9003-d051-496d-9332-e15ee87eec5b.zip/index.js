/* eslint-disable  func-names */
/* eslint quote-props: ["error", "consistent"]*/
/**
 * This sample demonstrates a simple skill built with the Amazon Alexa Skills
 * nodejs skill development kit.
 * This sample supports multiple lauguages. (en-US, en-GB, de-DE).
 * The Intent Schema, Custom Slots and Sample Utterances for this skill, as well
 * as testing instructions are located at https://github.com/alexa/skill-sample-nodejs-fact
 **/

'use strict';
const Alexa = require('alexa-sdk');
const request = require('request');
//var http = require('http'); 
//const db = require('./dbconnect');

const APP_ID = 'amzn1.ask.skill.b5bb03ac-50a1-4a20-80e5-5b8ac9fe6729';

const SKILL_NAME = 'UserRegistration';
const GET_REGO_MESSAGE = "Registration complete.";
const HELP_MESSAGE = 'You can say I want to register, or, you can say exit... What can I help you with?';
const HELP_REPROMPT = 'What can I help you with?';
const STOP_MESSAGE = 'Goodbye!';

function httpGet(info) {



    request.post({ url: 'https://ka1901.scem.westernsydney.edu.au/api/alexa/public/api/userdata', form: info }, function (err, httpResponse, body) {
        if (err) { return console.log(err); }
        console.log(body);

    });

}

const handlers = {
    'LaunchRequest': function () {
        this.emit(':ask', 'Welcome. Can you please provide your first name, age, gender, weight in kilos and height in centimetres?');
    },
    'userRegistrationIntent': function () {
        let name = this.event.request.intent.slots.name.value;
        const age = this.event.request.intent.slots.age.value;
        const weight = this.event.request.intent.slots.weight.value;
        const height = this.event.request.intent.slots.height.value;
        let gender = this.event.request.intent.slots.gender.value;

        const speechOutput = GET_REGO_MESSAGE + ' ' + name + ' ' + age + ' ' + weight + ' ' + height + ' ' + gender;

        var info = {
            age: age,
            name: name,
            weight: weight,
            gender: gender,
            height: height
        };
        httpGet(info);



        //this.response.cardRenderer(SKILL_NAME, bmr);
        this.response.speak(speechOutput);
        this.emit(':responseReady');


    },
    'AMAZON.HelpIntent': function () {
        const speechOutput = HELP_MESSAGE;
        const reprompt = HELP_REPROMPT;

        this.response.speak(speechOutput).listen(reprompt);
        this.emit(':responseReady');
    },
    'AMAZON.CancelIntent': function () {
        this.response.speak(STOP_MESSAGE);
        this.emit(':responseReady');
    },
    'AMAZON.StopIntent': function () {
        this.response.speak(STOP_MESSAGE);
        this.emit(':responseReady');
    },
};

exports.handler = function (event, context, callback) {
    const alexa = Alexa.handler(event, context, callback);
    alexa.APP_ID = APP_ID;
    alexa.registerHandlers(handlers);
    alexa.execute();
};
