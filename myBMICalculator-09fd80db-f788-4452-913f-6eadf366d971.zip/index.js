/* eslint-disable  func-names */
/* eslint quote-props: ["error", "consistent"]*/
/**
 * This sample demonstrates a simple skill built with the Amazon Alexa Skills
 * nodejs skill development kit.
 * This sample supports multiple lauguages. (en-US, en-GB, de-DE).
 * The Intent Schema, Custom Slots and Sample Utterances for this skill, as well
 * as testing instructions are located at https://github.com/alexa/skill-sample-nodejs-fact
 **/

'use strict';
const Alexa = require('alexa-sdk');

//=========================================================================================================================================
//TODO: The items below this comment need your attention.
//=========================================================================================================================================

//Replace with your app ID (OPTIONAL).  You can find this value at the top of your skill's page on http://developer.amazon.com.
//Make sure to enclose your value in quotes, like this: const APP_ID = 'amzn1.ask.skill.bb4045e6-b3e8-4133-b650-72923c5980f1';
const APP_ID = 'amzn1.ask.skill.93cf5a03-4588-4ba2-a742-2e468306b04b';

const SKILL_NAME = 'BMICalculator';
const GET_BMI_MESSAGE = "Your BMI is  ";
const HELP_MESSAGE = 'You can ask calculate my BMI, or, you can say exit... What can I help you with?';
const HELP_REPROMPT = 'What can I help you with?';
const STOP_MESSAGE = 'Goodbye!';

const handlers = {
    'LaunchRequest': function () {
        this.emit(':ask','Welcome. Can you please provide your weight in kilos and height in centimetres?');
    },
    'bmiCalculatorIntent': function () {
        const weight = this.event.request.intent.slots.weight.value;
        const height = this.event.request.intent.slots.height.value;
        const newHeight = height / 100;
        var bmi = weight / (newHeight * newHeight);
        const bmiRounded = Math.round(bmi * 10) / 10;
        let weightCategoryOutput = '';
        
        if(bmi < 18.5)
        {
            weightCategoryOutput = '. You are underweight.';
        }
        else if (bmi >= 18.5 && bmi <= 24.9)
        {
            weightCategoryOutput = '. You have a healthy weight.';
        }
        else if (bmi > 24.9 &&  bmi <= 29.9)
        {
            weightCategoryOutput = '. You are overweight.';
        }
        else
        {
            weightCategoryOutput = '. You are obese.';
        }
    
        const speechOutput = GET_BMI_MESSAGE + bmiRounded + weightCategoryOutput;
        //this.response.cardRenderer(SKILL_NAME, bmi);
        this.response.speak(speechOutput);
        console.log(speechOutput);
        this.emit(':responseReady');
    },
    'AMAZON.HelpIntent': function () {
        const speechOutput = HELP_MESSAGE;
        const reprompt = HELP_REPROMPT;

        this.response.speak(speechOutput).listen(reprompt);
        this.emit(':responseReady');
    },
    'AMAZON.CancelIntent': function () {
        this.response.speak(STOP_MESSAGE);
        this.emit(':responseReady');
    },
    'AMAZON.StopIntent': function () {
        this.response.speak(STOP_MESSAGE);
        this.emit(':responseReady');
    },
};

exports.handler = function (event, context, callback) {
    const alexa = Alexa.handler(event, context, callback);
    alexa.APP_ID = APP_ID;
    alexa.registerHandlers(handlers);
    alexa.execute();
};
